
  # Приложение с промтом

  This is a code bundle for Приложение с промтом. The original project is available at https://www.figma.com/design/QZQyxPrbB8ITMkOXeWzBQd/%D0%9F%D1%80%D0%B8%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5-%D1%81-%D0%BF%D1%80%D0%BE%D0%BC%D1%82%D0%BE%D0%BC.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  